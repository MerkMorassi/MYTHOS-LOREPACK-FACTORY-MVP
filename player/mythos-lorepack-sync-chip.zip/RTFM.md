RTFM: Mythos Lorepack Sync

WHAT: Honest courier between the kv shelf and the Studio roads. push(base) POSTs staged mint-wire rows to <base>/api/sync in 500s and reports the vault size; pull(url) GETs a JSONL/JSON-array pack and hands survivors to the host writeRows seam; status() reports local counts and roads. No storage, no keys, no DOM; every failure is a loud receipt, never a throw.
FILES: mythos-lorepack-sync-standalone.js + README.md + LICENSE-PROPRIETARY.txt
RUN:
<script src="mythos-lorepack-sync-standalone.js"></script>
var courier = window.MythosLorepackSync.client({ readRows: () => ROWS, writeRows: (r) => fileRows(r), fetch: fetch.bind(window), say: postStatus });
var st = await courier.status();
var sent = await courier.push();
var got = await courier.pull('https://example.com/pack.jsonl');
inputs: readRows seam (array or promise, errors read as empty); writeRows seam (receives pulled rows, returns {key} or {ok:false,...}; absent means HELD); fetch seam (defaults to global fetch); base (default http://localhost:4000, per-push override). Rows shaped {v,t,vec,m,d,src,ts,...}; textless rows dropped before send.
HOST: Host owns the rows (kv, mirror, file), the filing of pulled rows, and the Studio server at base. Courier never stores, never mints, never embeds.
PROOF: parse with new Function; status (counts + base + road); push happy (vaultSize surfaces, say progress); push 1205 rows in exactly 3 batches; push refusals (no-fetch, empty shelf, HTTP 500, thrown fetch); pull JSONL (2 pulled/1 skipped/filed) + JSON array; pull refusals (empty, 404, malformed, no URL, no-seam HELD); residue check (only MythosLorepackSync added, removed after).
