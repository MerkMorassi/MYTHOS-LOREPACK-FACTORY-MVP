# MYTHOS LOREPACK-SYNC - honest courier between the kv shelf and the Studio roads (for HOUSE AGENTS)

Origin: house-minted 2026-10-24 from user-supplied `scratch/message-attachments/mythos-lorepack-sync-standalone.js`, byte-exact in this ship (KINE lineage: MYTHOS-KINE `services/lorepack.ts` sync + `server.js` `/api/sync`, port 4000). Proven live 2026-10-24 in the mythos-chip-repo preview (status/push/pull, 17-case run beside the player kernel). Built to CHIP SPEC v1 with two recorded deviations (header comments kept, Node tolerance line pending — see honesty note). License: proprietary house (`LICENSE-PROPRIETARY.txt`).

## use

```html
<script src="mythos-lorepack-sync-standalone.js"></script>
<script>
  var courier = window.MythosLorepackSync.client({
    readRows: () => MY_LOREPACK_ROWS,   // [{v,t,vec,...}] or a promise of them
    writeRows: (rows) => fileRows(rows), // host files pulled rows, returns {key} or {ok:false,...}
    fetch: fetch.bind(window),            // host road; defaults to global fetch
    say: (t) => postStatus(t),            // optional sink; push progress rides here
    base: 'http://localhost:4000'         // Studio server; per-push override allowed
  });
  var st = await courier.status();
  var sent = await courier.push();                       // POSTs staged rows to <base>/api/sync
  var got = await courier.pull('https://example.com/pack.jsonl'); // GETs a pack, hands rows to writeRows
</script>
```

## the contract

- `client({readRows, writeRows, fetch, say, base})` — all five seams optional. Missing `readRows` reads as `[]`; missing `writeRows` holds pulled rows loud (never files, never throws); missing `fetch` falls back to global fetch; missing `say` stays silent. `base` defaults to `http://localhost:4000`, trailing slashes trimmed.
- `status()` → `{ok, base, localRows, fetchRoad, receipt}`. Counts local rows, names the roads. Never refuses.
- `push(baseOverride?)` → `{ok, pushed, vaultSize?, receipt}`. Normalizes rows (`{v:2, type, id, a, h, t, vec, m, d, src, ts}`; textless rows dropped), POSTs `{nodes}` in batches of 500 to `<base>/api/sync`, surfaces the server `vaultSize`, `say`s `pushed n/N` per batch. Overwrite is never sent (server default append stands). Refusals, all loud: no fetch road / no rows staged / `PUSH DIED` (fetch threw, batch number + `Is the Studio server up at <base>?`) / `PUSH REFUSED HTTP <n>` (first 160 chars of body).
- `pull(packUrl, fetchOverride?)` → `{ok, pulled, skipped, receipt}`. Accepts a JSONL pack (one row per line) or a JSON array; gz URLs gunzip when `DecompressionStream` exists, refuse loud when it does not. Every line is normalized; bad lines are counted in `skipped`, never thrown. Hands survivors to `writeRows`; no-seam files as HELD (`PULLED n HELD, not filed`). Refusals, all loud: no URL / no fetch road / gz-without-gunzip / empty pack / `PULL REFUSED HTTP <n>` / `PACK UNREADABLE` / `no rows survived (N skipped)`.
- `describe()` — one-line what.

## deliberately left out

- Watermark delta (push resends all rows every run; unlocks idempotent push; next iteration).
- SIGIL auth (FACTORY-MVP gate; unlocks keyed mint roads; this ship is keyless by construction).
- Strict v2 import gate (the courier stays lenient and tallies skips; strictness lives in the factory reader).
- Node tolerance line (pending user call; unlocks `require()` import).
- `/api/sync` retarget (current road is the KINE Studio server; FACTORY-MVP exposes no vault endpoint — see honesty note).

## honesty note

- The 17-line header comment block is retained byte-exact per the no-delete order. That is a deviation from §2 (no code comments), recorded here instead of hidden.
- The localhost road points at the deprecated KINE server. FACTORY-MVP has no `/api/sync`; until a new push target is blessed, localhost push lands only on a KINE Studio server.
- Push-twice duplicates (no watermark, server appends). Do not mistake a second push for a no-op.
- This chip is NOT the minter and NOT the vault. It reads rows others filed, moves bytes between roads, files nothing itself.
