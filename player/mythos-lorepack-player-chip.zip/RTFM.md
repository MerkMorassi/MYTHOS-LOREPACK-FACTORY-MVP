RTFM: Mythos Lorepack Player

WHAT: Local keyword recall over lorepack rows. recall(query,k) scores rows by shared words (stopwords out, 1 hit for short queries, 2 for longer, top-k max 5); block(query,k) formats the winners as a prompt block, empty when nothing is relevant. Rows arrive through the readRows seam, so the chip owns no storage.
FILES: mythos-lorepack-player-standalone.js + README.md + LICENSE-SALVAGE.txt
RUN:
<script src="mythos-lorepack-player-standalone.js"></script>
var player = window.MythosLorepackPlayer.client({ readRows: () => ROWS });
var hits = await player.recall("penguins", 3);
var block = await player.block("penguins", 3);
inputs: readRows seam (array or promise of [{id, t}], errors read as empty), optional say sink for recall counts. Query is plain words; k clamps 1-5, default 3.
HOST: Host owns the rows (kv, mirror, file, anything returning [{id, t}]), its own prompt assembly (append block blind, empty means quiet), and display of hits. No DOM, no fetch, no keys.
PROOF: parse with new Function; recall over 3 canned rows (penguin probe hits with scores, nonsense query quiet, stopword-only query empty); block shape (header plus id-tail lines, 200-char cuts); k clamp (0 defaults, 99 clamps to 5); broken readRows reads as empty; residue check (only MythosLorepackPlayer added, removed after).
