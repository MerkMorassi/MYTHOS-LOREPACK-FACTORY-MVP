# MYTHOS LOREPACK-PLAYER - local keyword recall over lorepack rows (for VOXPACK HOSTS)

Origin: user-supplied VOXPACK sandbox (mythos-neural-vox-ptt) recall kernel, byte-exact as attached 2026-10-24 (`scratch/message-attachments/mythos-lorepack-player-standalone.js`). Proven live 2026-10-24 in the mythos-chip-repo preview. Built to CHIP SPEC v1 with one recorded deviation (Node tolerance line pending) and one deliberate design deviation (quiet recall — see honesty note). Standing toward `src/LOREPACK-PLAYER-CONTRACT.md` v1 as its recall kernel; the import/verify/stats/chat-summary shell is owed. License: salvage, UNSPECIFIED (`LICENSE-SALVAGE.txt`; provenance user-supplied, no ownership asserted, do not relicense).

## use

```html
<script src="mythos-lorepack-player-standalone.js"></script>
<script>
  var player = window.MythosLorepackPlayer.client({
    readRows: () => MY_LOREPACK_ROWS,   // [{id, t, ...}] or a promise of them
    say: (t) => postStatus(t)            // optional sink, recall counts ride here
  });
  var hits = await player.recall("what did we say about penguins", 3);
  var block = await player.block("what did we say about penguins", 3);
</script>
```

## the contract

- `recall(query, k)` — plain array of `{id, text, score}` (max 5, default 3). Words under 3 letters and stopwords never count (tuned list includes domain verbs keep/hold/find/type — queries built on those words miss, by design). Short queries (1–2 content words) need 1 shared word; longer ones need 2. Empty, stopword-only, or broken-seam queries return `[]`. Never throws.
- `block(query, k)` — the prompt wire shape: `[LOREPACK RECALL (n)]` plus one `- text (id-tail)` line per hit, each text cut at 200 chars. Empty string when nothing is relevant, so callers append it blind. Recall counts ride the say seam.
- `describe()` — one-line what.
- `readRows` is the only door: sync array or promise, errors read as `[]`. The chip keeps no rows, files nothing, fetches nothing.

## deliberately left out

- Import/verify/stats/chat-summary shell (the contract player surface; owed next; this ship is the recall kernel only).
- Locus/agent filter (needs `agentId` plumbing on rows; unlocks per-agent recall).
- Embeddings and keyed paths (mint-side only; this chip is keyless by construction).
- Node tolerance line (pending user call; unlocks `require()` import).

## honesty note

- Keyword recall finds words, not meanings: paraphrases miss, exact words hit. Two shared words is a low bar on purpose — lorepack rows are short, and the block stays quiet whenever nothing clears it.
- The `need >= 2` rule for longer queries is stricter than the contract fallback (`score > 0` keeps). Example: `penguins xylophone quantum zebra` goes quiet here; the contract fallback would keep the penguin row at 1/4. Stricter is better for short rows, but the difference is real and recorded.
- `refuse()` is defined and reserved but unwired — kept per the no-delete order for the coming import shell, which will refuse loud. The recall path stays quiet by design; the justification lives here, not in silence.
- Salvage provenance is user-supplied and unverified beyond the live proof run. Behavior proven, ownership not asserted.
